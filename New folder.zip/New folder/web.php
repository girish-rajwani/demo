Route::any('save-demo', 'testing_controller@save_demo')->name('save-demo');

Route::any('demo', 'testing_controller@demo')->name('demo');

Route::any('get-model-data', 'testing_controller@get_model_data')->name('get-model-data');

Route::any('get-single-model-data', 'testing_controller@get_single_model_data')->name('get-single-model-data');

Route::any('sold-model', 'testing_controller@sold_model')->name('sold-model');