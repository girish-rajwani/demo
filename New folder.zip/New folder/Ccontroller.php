<?php
	public function demo(Request $request)
	{
		return view('demo');
	}
	public function save_demo(Request $request)
	{		
		$this->validate($request, [
			'filename' => 'required',
			'filename.*' => 'image|mimes:jpeg,png,jpg,gif,svg|max:2048'
		]);
		if($request->hasfile('filename'))
		{
			foreach($request->file('filename') as $image)
			{
				$name=$image->getClientOriginalName();
				$image->move(public_path().'/images/', $name);  
				$data[] = $name;  
			}
		}
		echo public_path().'/images/';
		dd($data);
		// $form= new Form();
		// $form->filename=json_encode($data);	
		// $form->save();
		//return back()->with('success', 'Your images has been successfully');
	}

	public function get_single_model_data(Request $request)
	{
		$id = $request->input('id');
		//$data = Model_details::where('id', $id)->get();
		$data = Model_details::Join('manufacturer_details', 'model_details.manufacturer_id', '=', 'manufacturer_details.id')
		->where('model_details.id', $id)
		->select('model_details.*', 'manufacturer_details.manufacturer_name')
		->get();
		echo json_encode($data);
	}

	public function get_model_data(Request $request)
	{
		//if($request->ajax()) 
		{
			$columns     = ['id', 'model_name', 'manufacturer_name', 'model_color', 'manufacturing_year', 'reg_number', 'note'];
			$draw        = $request->draw;
			$start       = $request->start; //Start is the offset
			$length      = $request->length; //How many records to show			
			$column      = $request->order[0]['column']; //Column to orderBy			
			$dir         = $request->order[0]['dir']; //Direction of orderBy
			$searchValue = $request->search['value']; //Search value
			
			//Sets the current page
			Paginator::currentPageResolver(function () use ($start, $length) {
				return ($start / $length + 1);
			});
			
			$model = Model_details::Join('manufacturer_details', 'model_details.manufacturer_id', '=', 'manufacturer_details.id')
			->where('model_details.count', '>', 0)
			->select('model_details.*', 'manufacturer_details.manufacturer_name')
			->orderBy($columns[$column], $dir)
			->paginate($length);			
			
			return [
				'draw' => $draw,
				'recordsTotal' => $model->total(),
				'recordsFiltered' => $model->total(),
				'data' => $model
			];
		}
	}

	public function sold_model(Request $request)
	{
		$id = $request->input('id');
		$row = Model_details::find($id)->first();				
		$count = ($row->count) - 1;		
		Model_details::where('id', $id)->update(['count' => $count]);
		return redirect()->route('car-details');
	}
?>